import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Camera, MapPin, AlertCircle, CheckCircle, Clock } from "lucide-react";

export default function MapPage() {
  const navigate = useNavigate();
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<any>(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [showLoginAlert, setShowLoginAlert] = useState(false);
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [complaints, setComplaints] = useState<any[]>([]);

  useEffect(() => {
    checkAuthStatus();
    initializeMap();
    fetchComplaints();
    getUserLocation();

    return () => {
      if (map.current) {
        map.current.remove();
        map.current = null;
      }
    };
  }, []);

  const checkAuthStatus = () => {
    const token = localStorage.getItem("userToken");
    setIsLoggedIn(!!token);
  };

  const getUserLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) => {
        const { latitude, longitude } = position.coords;
        setUserLocation({ lat: latitude, lng: longitude });
      });
    }
  };

  const initializeMap = () => {
    if (!mapContainer.current || map.current) return;

    const L = (window as any).L;
    if (!L) {
      console.error("Leaflet not loaded");
      return;
    }

    map.current = L.map(mapContainer.current).setView([28.6139, 77.2090], 13);

    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: "&copy; OpenStreetMap contributors",
      maxZoom: 19,
    }).addTo(map.current);
  };

  const fetchComplaints = async () => {
    try {
      const response = await fetch("/api/complaints");
      if (!response.ok) {
        setComplaints([]);
        return;
      }
      const data = await response.json();
      setComplaints(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error("Error fetching complaints:", error);
      setComplaints([]);
    }
  };

  const handleCameraClick = () => {
    if (!isLoggedIn) {
      setShowLoginAlert(true);
      setTimeout(() => setShowLoginAlert(false), 4000);
      return;
    }
    navigate("/camera");
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-status-pending";
      case "in-progress":
        return "bg-status-in-progress";
      case "completed":
        return "bg-status-completed";
      default:
        return "bg-gray-400";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pending":
        return <AlertCircle className="w-4 h-4" />;
      case "in-progress":
        return <Clock className="w-4 h-4" />;
      case "completed":
        return <CheckCircle className="w-4 h-4" />;
      default:
        return <MapPin className="w-4 h-4" />;
    }
  };

  return (
    <div className="relative w-full h-screen bg-background overflow-hidden">
      {/* Top Navigation Bar */}
      <div className="absolute top-0 left-0 right-0 z-10 bg-white shadow-md border-b border-border">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-gradient-to-br from-primary to-secondary rounded-lg flex items-center justify-center">
              <MapPin className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              MyCity
            </h1>
          </div>
          <button
            onClick={() => navigate(isLoggedIn ? "/logout" : "/login")}
            className="px-6 py-2 rounded-lg font-semibold transition-all duration-300 bg-primary text-primary-foreground hover:shadow-lg hover:scale-105"
          >
            {isLoggedIn ? "Logout" : "Login"}
          </button>
        </div>
      </div>

      {/* Map Container */}
      <div
        ref={mapContainer}
        className="absolute top-16 left-0 right-0 bottom-0 w-full h-full z-0"
        style={{ height: "calc(100vh - 64px)" }}
      />

      {/* Login Alert Toast */}
      {showLoginAlert && (
        <div className="absolute top-24 left-1/2 transform -translate-x-1/2 z-20 bg-white border-l-4 border-status-pending shadow-lg rounded-lg p-4 max-w-sm animate-in slide-in-from-top-2">
          <div className="flex items-center gap-3">
            <AlertCircle className="w-5 h-5 text-status-pending flex-shrink-0" />
            <p className="text-foreground font-medium">Please login to submit a complaint.</p>
          </div>
        </div>
      )}

      {/* Floating Camera Button */}
      <button
        onClick={handleCameraClick}
        className="absolute bottom-8 right-8 z-20 w-16 h-16 bg-gradient-to-br from-primary to-secondary rounded-full shadow-2xl hover:shadow-3xl flex items-center justify-center group transition-all duration-300 hover:scale-110 active:scale-95"
      >
        <div className="absolute inset-0 bg-gradient-to-br from-primary to-secondary rounded-full opacity-0 group-hover:opacity-20 animate-pulse" />
        <Camera className="w-8 h-8 text-white relative z-10" />
      </button>

      {/* Quick Actions Card */}
      <div className="absolute bottom-8 left-8 z-20 bg-white rounded-xl shadow-lg p-4 max-w-xs border border-border">
        <h3 className="font-semibold text-foreground mb-3 text-sm flex items-center gap-2">
          <MapPin className="w-4 h-4 text-primary" />
          Recent Issues
        </h3>
        <div className="space-y-2 max-h-40 overflow-y-auto">
          {complaints.slice(0, 3).map((complaint) => (
            <div
              key={complaint.id}
              className="p-2 bg-muted rounded-lg text-sm hover:bg-accent/10 cursor-pointer transition-colors"
            >
              <div className="flex items-center gap-2 mb-1">
                <div className={`w-2 h-2 rounded-full ${getStatusColor(complaint.status)}`} />
                <span className="font-medium text-xs text-foreground">{complaint.problem_type}</span>
              </div>
              <p className="text-xs text-muted-foreground line-clamp-1">{complaint.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
