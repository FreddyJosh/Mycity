import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { LogOut, MapPin, Image as ImageIcon, CheckCircle, Clock, AlertCircle } from "lucide-react";

export default function DeptDashboard() {
  const navigate = useNavigate();
  const [complaints, setComplaints] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedComplaint, setSelectedComplaint] = useState<any | null>(null);
  const [afterPhoto, setAfterPhoto] = useState<string | null>(null);
  const [updateStatus, setUpdateStatus] = useState("");

  useEffect(() => {
    checkAuth();
    fetchComplaints();
  }, []);

  const checkAuth = () => {
    const token = localStorage.getItem("deptToken");
    if (!token) {
      navigate("/dept-login");
    }
  };

  const fetchComplaints = async () => {
    try {
      const token = localStorage.getItem("deptToken");
      const response = await fetch("/api/complaints/dept", {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (!response.ok) {
        setComplaints([]);
        setLoading(false);
        return;
      }

      const data = await response.json();
      setComplaints(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error("Error fetching complaints:", error);
      setComplaints([]);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("deptToken");
    navigate("/dept-login");
  };

  const handleUpdateStatus = async () => {
    if (!selectedComplaint) return;

    try {
      const token = localStorage.getItem("deptToken");
      const response = await fetch(`/api/complaints/${selectedComplaint.id}/update`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          status: updateStatus,
          image_after: afterPhoto,
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to update complaint");
      }

      setSelectedComplaint(null);
      setAfterPhoto(null);
      setUpdateStatus("");
      fetchComplaints();
    } catch (error) {
      console.error("Error updating complaint:", error);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-status-pending";
      case "in-progress":
        return "bg-status-in-progress";
      case "completed":
        return "bg-status-completed";
      default:
        return "bg-gray-400";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pending":
        return <AlertCircle className="w-4 h-4" />;
      case "in-progress":
        return <Clock className="w-4 h-4" />;
      case "completed":
        return <CheckCircle className="w-4 h-4" />;
      default:
        return <MapPin className="w-4 h-4" />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100 p-6">
      {/* Header */}
      <div className="max-w-6xl mx-auto mb-8">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold text-foreground">Department Dashboard</h1>
          <button
            onClick={handleLogout}
            className="flex items-center gap-2 px-4 py-2 bg-status-pending text-white rounded-lg hover:bg-status-pending/90 transition-colors font-semibold"
          >
            <LogOut className="w-5 h-5" />
            Logout
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Complaints List */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-2xl shadow-xl border border-border overflow-hidden">
            <div className="p-6 border-b border-border">
              <h2 className="text-xl font-bold text-foreground">
                Assigned Complaints ({complaints.length})
              </h2>
            </div>

            <div className="divide-y divide-border max-h-[600px] overflow-y-auto">
              {loading ? (
                <div className="p-6 text-center text-muted-foreground">Loading...</div>
              ) : complaints.length === 0 ? (
                <div className="p-6 text-center text-muted-foreground">
                  No complaints assigned yet
                </div>
              ) : (
                complaints.map((complaint) => (
                  <button
                    key={complaint.id}
                    onClick={() => {
                      setSelectedComplaint(complaint);
                      setUpdateStatus(complaint.status);
                    }}
                    className={`w-full p-4 text-left hover:bg-muted transition-colors ${
                      selectedComplaint?.id === complaint.id ? "bg-primary/10 border-l-4 border-l-primary" : ""
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <span className="px-3 py-1 bg-blue-100 text-primary text-xs font-semibold rounded-full">
                            {complaint.problem_type}
                          </span>
                          <div className={`${getStatusColor(complaint.status)} text-white px-3 py-1 rounded-full text-xs font-semibold flex items-center gap-1`}>
                            {getStatusIcon(complaint.status)}
                            {complaint.status}
                          </div>
                        </div>
                        <p className="font-semibold text-foreground mb-1">{complaint.description}</p>
                        <p className="text-xs text-muted-foreground flex items-center gap-1">
                          <MapPin className="w-3 h-3" />
                          {complaint.latitude.toFixed(4)}, {complaint.longitude.toFixed(4)}
                        </p>
                      </div>
                    </div>
                  </button>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Details Panel */}
        {selectedComplaint && (
          <div className="bg-white rounded-2xl shadow-xl border border-border p-6 h-fit sticky top-6">
            <h3 className="text-lg font-bold text-foreground mb-4">Complaint Details</h3>

            {/* Before Photo */}
            {selectedComplaint.image_before && (
              <div className="mb-4">
                <p className="text-sm font-semibold text-foreground mb-2">Before Photo</p>
                <img
                  src={selectedComplaint.image_before}
                  alt="Before"
                  className="w-full h-32 object-cover rounded-lg border border-border"
                />
              </div>
            )}

            {/* After Photo Upload */}
            <div className="mb-4">
              <p className="text-sm font-semibold text-foreground mb-2">After Photo</p>
              <div className="relative">
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => {
                    if (e.target.files?.[0]) {
                      const reader = new FileReader();
                      reader.onload = (event) => {
                        setAfterPhoto(event.target?.result as string);
                      };
                      reader.readAsDataURL(e.target.files[0]);
                    }
                  }}
                  className="hidden"
                  id="afterPhotoInput"
                />
                <label
                  htmlFor="afterPhotoInput"
                  className="block w-full p-3 border-2 border-dashed border-border rounded-lg text-center cursor-pointer hover:border-primary/50 transition-colors"
                >
                  {afterPhoto ? (
                    <img
                      src={afterPhoto}
                      alt="After"
                      className="w-full h-32 object-cover rounded-lg"
                    />
                  ) : (
                    <div className="flex flex-col items-center gap-2 py-4">
                      <ImageIcon className="w-6 h-6 text-muted-foreground" />
                      <span className="text-sm text-muted-foreground">Click to upload after photo</span>
                    </div>
                  )}
                </label>
              </div>
            </div>

            {/* Status Update */}
            <div className="mb-4">
              <p className="text-sm font-semibold text-foreground mb-2">Update Status</p>
              <select
                value={updateStatus}
                onChange={(e) => setUpdateStatus(e.target.value)}
                className="w-full px-3 py-2 border border-border rounded-lg focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition bg-input"
              >
                <option value="pending">Pending</option>
                <option value="in-progress">In Progress</option>
                <option value="completed">Completed</option>
              </select>
            </div>

            {/* Submit Button */}
            <button
              onClick={handleUpdateStatus}
              className="w-full py-2 bg-gradient-to-r from-primary to-secondary text-white font-semibold rounded-lg hover:shadow-lg transition-all duration-300"
            >
              Update Status
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
