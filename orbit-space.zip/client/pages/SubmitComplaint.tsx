import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { MapPin, Upload, Send, ArrowLeft } from "lucide-react";

const PROBLEM_TYPES = [
  "Pothole",
  "Garbage Issue",
  "Broken Street Light",
  "Waterlogging",
  "Illegal Dumping",
  "Road Damage",
  "Sewage Problem",
];

export default function SubmitComplaint() {
  const navigate = useNavigate();
  const [photo, setPhoto] = useState<string | null>(null);
  const [problemType, setProblemType] = useState("");
  const [description, setDescription] = useState("");
  const [location, setLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    const capturedPhoto = localStorage.getItem("capturedPhoto");
    if (capturedPhoto) {
      setPhoto(capturedPhoto);
    }

    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) => {
        setLocation({
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        });
      });
    }
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!problemType || !description || !photo) {
      setError("Please fill in all required fields");
      return;
    }

    setLoading(true);

    try {
      const response = await fetch("/api/complaints/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          problem_type: problemType,
          description,
          image_before: photo,
          latitude: location?.lat || 0,
          longitude: location?.lng || 0,
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to submit complaint");
      }

      localStorage.removeItem("capturedPhoto");
      navigate("/", { replace: true });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to submit complaint");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100 p-4">
      {/* Header */}
      <div className="max-w-2xl mx-auto pt-4">
        <button
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 text-primary font-semibold mb-6 hover:gap-3 transition-all"
        >
          <ArrowLeft className="w-5 h-5" />
          Back
        </button>

        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-foreground">Report an Issue</h1>
          <p className="text-muted-foreground mt-2">
            Help us improve your city by reporting problems
          </p>
        </div>
      </div>

      {/* Form Card */}
      <div className="max-w-2xl mx-auto bg-white rounded-2xl shadow-xl p-8 border border-border">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Photo Preview */}
          {photo && (
            <div className="rounded-xl overflow-hidden border-2 border-border">
              <img src={photo} alt="Captured" className="w-full h-64 object-cover" />
              <div className="p-3 bg-muted text-sm text-muted-foreground text-center">
                Photo captured - Click to retake
              </div>
            </div>
          )}

          {/* Problem Type */}
          <div>
            <label className="block text-sm font-semibold text-foreground mb-3">
              Problem Type *
            </label>
            <div className="grid grid-cols-2 gap-3">
              {PROBLEM_TYPES.map((type) => (
                <button
                  key={type}
                  type="button"
                  onClick={() => setProblemType(type)}
                  className={`p-3 rounded-lg font-medium transition-all duration-300 border-2 ${
                    problemType === type
                      ? "border-primary bg-primary text-white shadow-lg"
                      : "border-border bg-white text-foreground hover:border-primary/50"
                  }`}
                >
                  {type}
                </button>
              ))}
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-sm font-semibold text-foreground mb-2">
              Description *
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe the issue in detail..."
              rows={4}
              className="w-full px-4 py-3 rounded-lg border border-border focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition bg-input resize-none"
              required
            />
          </div>

          {/* Location */}
          {location && (
            <div className="flex items-center gap-3 p-4 bg-blue-50 rounded-lg border border-border">
              <MapPin className="w-5 h-5 text-primary flex-shrink-0" />
              <div className="text-sm">
                <p className="font-semibold text-foreground">Location Detected</p>
                <p className="text-muted-foreground">
                  {location.lat.toFixed(4)}, {location.lng.toFixed(4)}
                </p>
              </div>
            </div>
          )}

          {/* Error Message */}
          {error && (
            <div className="p-4 bg-status-pending/10 text-status-pending rounded-lg font-medium">
              {error}
            </div>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-gradient-to-r from-primary to-secondary text-white font-semibold rounded-lg hover:shadow-lg transition-all duration-300 disabled:opacity-50 flex items-center justify-center gap-2"
          >
            <Send className="w-5 h-5" />
            {loading ? "Submitting..." : "Submit Complaint"}
          </button>
        </form>
      </div>
    </div>
  );
}
