import { useRef, useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Camera, RotateCcw, Check, X } from "lucide-react";

export default function CameraPage() {
  const navigate = useNavigate();
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [capturedPhoto, setCapturedPhoto] = useState<string | null>(null);
  const [cameraActive, setCameraActive] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    startCamera();

    return () => {
      stopCamera();
    };
  }, []);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment" },
      });

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setCameraActive(true);
      }
    } catch (err) {
      setError("Unable to access camera. Please check permissions.");
      console.error("Camera error:", err);
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach((track) => track.stop());
    }
  };

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const context = canvasRef.current.getContext("2d");
      if (context) {
        canvasRef.current.width = videoRef.current.videoWidth;
        canvasRef.current.height = videoRef.current.videoHeight;
        context.drawImage(videoRef.current, 0, 0);
        const photo = canvasRef.current.toDataURL("image/jpeg");
        setCapturedPhoto(photo);
        stopCamera();
      }
    }
  };

  const retakePhoto = () => {
    setCapturedPhoto(null);
    startCamera();
  };

  const usePhoto = () => {
    if (capturedPhoto) {
      localStorage.setItem("capturedPhoto", capturedPhoto);
      navigate("/submit-complaint");
    }
  };

  return (
    <div className="w-full h-screen bg-black flex flex-col items-center justify-center relative overflow-hidden">
      {/* Close Button */}
      <button
        onClick={() => navigate(-1)}
        className="absolute top-6 right-6 z-10 bg-white/20 hover:bg-white/30 text-white rounded-full p-3 transition-colors"
      >
        <X className="w-6 h-6" />
      </button>

      <canvas ref={canvasRef} className="hidden" />

      {error && (
        <div className="absolute top-20 left-1/2 transform -translate-x-1/2 bg-red-500 text-white px-6 py-3 rounded-lg">
          {error}
        </div>
      )}

      {!capturedPhoto ? (
        <>
          {/* Video Feed */}
          <video
            ref={videoRef}
            autoPlay
            playsInline
            className="w-full h-full object-cover"
          />

          {/* Camera Controls */}
          <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex items-center gap-4">
            <button
              onClick={() => navigate(-1)}
              className="w-14 h-14 bg-white/20 hover:bg-white/30 rounded-full flex items-center justify-center text-white transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
            <button
              onClick={capturePhoto}
              className="w-20 h-20 bg-white rounded-full flex items-center justify-center hover:shadow-2xl transition-all duration-300 active:scale-95"
            >
              <Camera className="w-8 h-8 text-black" />
            </button>
            <div className="w-14 h-14" />
          </div>
        </>
      ) : (
        <>
          {/* Captured Photo Preview */}
          <img
            src={capturedPhoto}
            alt="Captured"
            className="w-full h-full object-cover"
          />

          {/* Photo Action Buttons */}
          <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex items-center gap-4">
            <button
              onClick={retakePhoto}
              className="w-14 h-14 bg-white/20 hover:bg-white/30 rounded-full flex items-center justify-center text-white transition-colors"
            >
              <RotateCcw className="w-6 h-6" />
            </button>
            <button
              onClick={usePhoto}
              className="w-20 h-20 bg-green-500 hover:bg-green-600 rounded-full flex items-center justify-center hover:shadow-2xl transition-all duration-300 active:scale-95"
            >
              <Check className="w-8 h-8 text-white" />
            </button>
            <div className="w-14 h-14" />
          </div>
        </>
      )}

      {/* Top Gradient Overlay */}
      <div className="absolute top-0 left-0 right-0 h-32 bg-gradient-to-b from-black/50 to-transparent pointer-events-none" />
    </div>
  );
}
