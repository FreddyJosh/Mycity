import { RequestHandler, Router } from "express";
import { User } from "../models/User";
import { OTP } from "../models/OTP";
import { generateToken } from "../middleware/auth";

const router = Router();

// In-memory storage fallback (for testing without database)
const inMemoryUsers: any[] = [];
const inMemoryOTPs: any[] = [];

// Generate random OTP
const generateOTP = () => Math.floor(100000 + Math.random() * 900000).toString();

// Send OTP to email
const sendOTP: RequestHandler = async (req, res) => {
  try {
    const { email, username } = req.body;

    if (!email || !username) {
      res.status(400).json({ error: "Email and username required" });
      return;
    }

    // Try database first, fallback to in-memory
    let existingUser = null;
    let existingUsername = null;

    try {
      existingUser = await User.findByEmail(email);
      existingUsername = await User.findByUsername(username);
    } catch {
      // Database error, use in-memory fallback
      existingUser = inMemoryUsers.find((u: any) => u.email === email);
      existingUsername = inMemoryUsers.find((u: any) => u.username === username);
    }

    if (existingUser) {
      res.status(400).json({ error: "Email already registered" });
      return;
    }

    if (existingUsername) {
      res.status(400).json({ error: "Username already taken" });
      return;
    }

    const otp = generateOTP();

    // Try to save OTP to database, fallback to in-memory
    try {
      await OTP.create(email, otp);
    } catch {
      // Database error, use in-memory
      inMemoryOTPs.push({
        email,
        otp,
        expires_at: new Date(Date.now() + 10 * 60 * 1000),
      });
    }

    // Log OTP for testing
    console.log(`✅ OTP for ${email}: ${otp}`);

    res.json({ message: "OTP sent to email" });
  } catch (error) {
    console.error("Send OTP error:", error);
    res.status(500).json({ error: "Failed to send OTP" });
  }
};

// Verify OTP
const verifyOTP: RequestHandler = async (req, res) => {
  try {
    const { email, otp } = req.body;

    let isValid = false;

    // Try database first
    try {
      isValid = await OTP.verify(email, otp);
    } catch {
      // Database error, use in-memory
      const otpEntry = inMemoryOTPs.find((o: any) => o.email === email && o.otp === otp);
      if (otpEntry && new Date() < new Date(otpEntry.expires_at)) {
        isValid = true;
        // Remove used OTP
        inMemoryOTPs.splice(inMemoryOTPs.indexOf(otpEntry), 1);
      }
    }

    if (!isValid) {
      res.status(400).json({ error: "Invalid or expired OTP" });
      return;
    }

    res.json({ message: "OTP verified" });
  } catch (error) {
    console.error("Verify OTP error:", error);
    res.status(500).json({ error: "Failed to verify OTP" });
  }
};

// Register user
const register: RequestHandler = async (req, res) => {
  try {
    const { email, username, password } = req.body;

    if (!email || !username || !password) {
      res.status(400).json({ error: "Missing required fields" });
      return;
    }

    let existingUser = null;
    let existingUsername = null;
    let userId = 0;

    // Try database first
    try {
      existingUser = await User.findByEmail(email);
      existingUsername = await User.findByUsername(username);

      if (existingUser || existingUsername) {
        res.status(400).json({
          error: existingUser ? "Email already registered" : "Username already taken",
        });
        return;
      }

      const result = await User.create(username, email, password);
      userId = (result as any).insertId;
    } catch {
      // Database error, use in-memory
      existingUser = inMemoryUsers.find((u: any) => u.email === email);
      existingUsername = inMemoryUsers.find((u: any) => u.username === username);

      if (existingUser || existingUsername) {
        res.status(400).json({
          error: existingUser ? "Email already registered" : "Username already taken",
        });
        return;
      }

      userId = inMemoryUsers.length + 1;
      inMemoryUsers.push({ id: userId, username, email, password });
    }

    const token = generateToken(userId);

    res.status(201).json({
      token,
      user: { id: userId, username, email },
    });
  } catch (error) {
    console.error("Register error:", error);
    res.status(500).json({ error: "Failed to register" });
  }
};

// Login user
const login: RequestHandler = async (req, res) => {
  try {
    const { username, password } = req.body;

    if (!username || !password) {
      res.status(400).json({ error: "Missing username or password" });
      return;
    }

    let user = null;

    // Try database first
    try {
      user = await User.findByUsername(username);

      if (user) {
        const isValidPassword = await User.validatePassword(password, user.password_hash);
        if (!isValidPassword) {
          res.status(401).json({ error: "Invalid credentials" });
          return;
        }

        const token = generateToken(user.id);
        res.json({
          token,
          user: { id: user.id, username: user.username, email: user.email },
        });
        return;
      }
    } catch {
      // Database error, use in-memory
    }

    // Check in-memory storage
    user = inMemoryUsers.find((u: any) => u.username === username);
    if (!user || user.password !== password) {
      res.status(401).json({ error: "Invalid credentials" });
      return;
    }

    const token = generateToken(user.id);
    res.json({
      token,
      user: { id: user.id, username: user.username, email: user.email },
    });
  } catch (error) {
    console.error("Login error:", error);
    res.status(500).json({ error: "Failed to login" });
  }
};

router.post("/send-otp", sendOTP);
router.post("/verify-otp", verifyOTP);
router.post("/register", register);
router.post("/login", login);

export default router;
