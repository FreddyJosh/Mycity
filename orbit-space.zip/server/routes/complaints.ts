import { RequestHandler, Router } from "express";
import { Complaint } from "../models/Complaint";
import { Department } from "../models/Department";
import { authenticateUser, authenticateDepartment } from "../middleware/auth";

const router = Router();

// In-memory storage fallback
const inMemoryComplaints: any[] = [];

// Get all complaints
const getAllComplaints: RequestHandler = async (_req, res) => {
  try {
    let complaints: any[] = [];

    try {
      const dbComplaints = await Complaint.getAll();
      complaints = Array.isArray(dbComplaints) ? dbComplaints : [];
    } catch {
      // Database error, use in-memory
    }

    // Add in-memory complaints
    complaints = [...complaints, ...inMemoryComplaints];

    res.json(complaints);
  } catch (error) {
    console.error("Error fetching complaints:", error);
    // Return in-memory complaints
    res.json(inMemoryComplaints);
  }
};

// Get department complaints
const getDeptComplaints: RequestHandler = async (req, res) => {
  try {
    if (!req.departmentId) {
      res.json([]);
      return;
    }

    let complaints: any[] = [];

    try {
      const dbComplaints = await Complaint.getByDepartment(req.departmentId);
      complaints = Array.isArray(dbComplaints) ? dbComplaints : [];
    } catch {
      // Database error, use in-memory
    }

    // Add in-memory complaints filtered by department
    const filteredMemory = inMemoryComplaints.filter((c: any) =>
      [1, 2, 3, 4, 5, 6].includes(req.departmentId)
    );

    complaints = [...complaints, ...filteredMemory];
    res.json(complaints);
  } catch (error) {
    console.error("Error fetching department complaints:", error);
    res.json(inMemoryComplaints);
  }
};

// Create complaint
const createComplaint: RequestHandler = async (req, res) => {
  try {
    const { problem_type, description, image_before, latitude, longitude } = req.body;

    if (!problem_type || !description || !image_before) {
      res.status(400).json({ error: "Missing required fields" });
      return;
    }

    // Use authenticated user or default to 1 for testing
    const userId = req.userId || 1;

    let complaint = null;

    // Try database first
    try {
      const result = await Complaint.create(
        userId,
        problem_type,
        description,
        image_before,
        latitude,
        longitude
      );

      complaint = await Complaint.getById((result as any).insertId);
    } catch {
      // Database error, use in-memory
      const id = inMemoryComplaints.length + 1;
      complaint = {
        id,
        user_id: userId,
        problem_type,
        description,
        image_before,
        image_after: null,
        latitude,
        longitude,
        status: "pending",
        created_at: new Date().toISOString(),
      };
      inMemoryComplaints.push(complaint);
    }

    res.status(201).json(complaint);
  } catch (error) {
    console.error("Error creating complaint:", error);
    res.status(500).json({ error: "Failed to create complaint" });
  }
};

// Update complaint status
const updateComplaint: RequestHandler = async (req, res) => {
  try {
    if (!req.departmentId) {
      res.status(401).json({ error: "Unauthorized" });
      return;
    }

    const { id } = req.params;
    const { status, image_after } = req.body;

    if (!status) {
      res.status(400).json({ error: "Status is required" });
      return;
    }

    const complaintId = parseInt(id);

    // Try database first
    try {
      const complaint = await Complaint.getById(complaintId);
      if (!complaint) {
        throw new Error("Not found in DB");
      }

      if (complaint.department_id !== req.departmentId) {
        res.status(403).json({ error: "Unauthorized" });
        return;
      }

      await Complaint.updateStatus(complaintId, status, image_after);
      const updatedComplaint = await Complaint.getById(complaintId);
      res.json(updatedComplaint);
      return;
    } catch {
      // Database error, check in-memory
    }

    // Check in-memory
    const complaint = inMemoryComplaints.find((c: any) => c.id === complaintId);
    if (!complaint) {
      res.status(404).json({ error: "Complaint not found" });
      return;
    }

    complaint.status = status;
    if (image_after) {
      complaint.image_after = image_after;
    }

    res.json(complaint);
  } catch (error) {
    console.error("Error updating complaint:", error);
    res.status(500).json({ error: "Failed to update complaint" });
  }
};

router.get("/", getAllComplaints);
router.get("/dept", authenticateDepartment, getDeptComplaints);
router.post("/create", createComplaint);
router.put("/:id/update", authenticateDepartment, updateComplaint);

export default router;
