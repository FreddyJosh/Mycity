import { RequestHandler, Router } from "express";
import { Department } from "../models/Department";
import { generateDeptToken } from "../middleware/auth";

const router = Router();

// Hardcoded departments (fallback)
const DEPARTMENTS = [
  { id: 1, name: "Roadways", email: "roadways@mycity.gov", password_hash: "dept123" },
  { id: 2, name: "Sanitary", email: "sanitary@mycity.gov", password_hash: "dept123" },
  { id: 3, name: "Drainage", email: "drainage@mycity.gov", password_hash: "dept123" },
  { id: 4, name: "Water Supply", email: "water@mycity.gov", password_hash: "dept123" },
  { id: 5, name: "Street Light", email: "streetlight@mycity.gov", password_hash: "dept123" },
  { id: 6, name: "EB Department", email: "eb@mycity.gov", password_hash: "dept123" },
];

// Department login
const login: RequestHandler = async (req, res) => {
  try {
    const { department, email, password } = req.body;

    if (!department || !email || !password) {
      res.status(400).json({ error: "Missing required fields" });
      return;
    }

    let dept = null;

    // Try database first
    try {
      dept = await Department.findByName(department);
    } catch {
      // Database error, use hardcoded fallback
    }

    // Fallback to hardcoded departments
    if (!dept) {
      dept = DEPARTMENTS.find(
        (d) => d.name === department && d.email === email && d.password_hash === password
      );
    } else if (dept.email !== email || dept.password_hash !== password) {
      res.status(401).json({ error: "Invalid credentials" });
      return;
    }

    if (!dept) {
      res.status(401).json({ error: "Invalid credentials" });
      return;
    }

    const token = generateDeptToken(dept.id);

    res.json({
      token,
      department: { id: dept.id, name: dept.name, email: dept.email },
    });
  } catch (error) {
    console.error("Department login error:", error);
    res.status(500).json({ error: "Failed to login" });
  }
};

// Get all departments
const getAll: RequestHandler = async (_req, res) => {
  try {
    const departments = await Department.getAll();
    res.json(departments);
  } catch (error) {
    console.error("Error fetching departments:", error);
    res.status(500).json({ error: "Failed to fetch departments" });
  }
};

router.post("/login", login);
router.get("/", getAll);

export default router;
