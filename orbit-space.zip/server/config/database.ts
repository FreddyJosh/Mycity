import mysql from "mysql2/promise";

const pool = mysql.createPool({
  host: process.env.DB_HOST || "localhost",
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME || "withoutai",
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  enableKeepAlive: true,
  keepAliveInitialDelayMs: 0,
});

export default pool;

// Initialize database tables
export async function initializeDatabase() {
  const connection = await pool.getConnection();

  try {
    // Create users table
    await connection.execute(`
      CREATE TABLE IF NOT EXISTS users (
        id INT PRIMARY KEY AUTO_INCREMENT,
        username VARCHAR(255) UNIQUE NOT NULL,
        email VARCHAR(255) UNIQUE NOT NULL,
        password_hash VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Create complaints table
    await connection.execute(`
      CREATE TABLE IF NOT EXISTS complaints (
        id INT PRIMARY KEY AUTO_INCREMENT,
        user_id INT NOT NULL,
        department_id INT,
        problem_type VARCHAR(255) NOT NULL,
        description TEXT NOT NULL,
        image_before LONGTEXT,
        image_after LONGTEXT,
        latitude DECIMAL(10, 8),
        longitude DECIMAL(11, 8),
        status ENUM('pending', 'in-progress', 'completed') DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      )
    `);

    // Create departments table
    await connection.execute(`
      CREATE TABLE IF NOT EXISTS departments (
        id INT PRIMARY KEY AUTO_INCREMENT,
        name VARCHAR(255) UNIQUE NOT NULL,
        email VARCHAR(255) UNIQUE NOT NULL,
        password_hash VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Create otp_table
    await connection.execute(`
      CREATE TABLE IF NOT EXISTS otp_table (
        id INT PRIMARY KEY AUTO_INCREMENT,
        email VARCHAR(255) NOT NULL,
        otp VARCHAR(6) NOT NULL,
        expires_at TIMESTAMP NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    console.log("✅ Database tables initialized successfully");

    // Insert default departments if they don't exist
    const departments = [
      { name: "Roadways", email: "roadways@mycity.gov", password: "dept123" },
      { name: "Sanitary", email: "sanitary@mycity.gov", password: "dept123" },
      { name: "Drainage", email: "drainage@mycity.gov", password: "dept123" },
      { name: "Water Supply", email: "water@mycity.gov", password: "dept123" },
      { name: "Street Light", email: "streetlight@mycity.gov", password: "dept123" },
      { name: "EB Department", email: "eb@mycity.gov", password: "dept123" },
    ];

    for (const dept of departments) {
      await connection.execute(
        `INSERT IGNORE INTO departments (name, email, password_hash) VALUES (?, ?, ?)`,
        [dept.name, dept.email, dept.password]
      );
    }

    console.log("✅ Default departments inserted");
  } catch (error) {
    console.error("Database initialization error:", error);
  } finally {
    connection.release();
  }
}
