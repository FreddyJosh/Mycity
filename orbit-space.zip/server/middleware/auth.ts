import { RequestHandler } from "express";
import jwt from "jsonwebtoken";

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key-change-in-production";

declare global {
  namespace Express {
    interface Request {
      userId?: number;
      departmentId?: number;
    }
  }
}

export function generateToken(userId: number, type: "user" = "user"): string {
  return jwt.sign({ userId, type }, JWT_SECRET, { expiresIn: "7d" });
}

export function generateDeptToken(departmentId: number): string {
  return jwt.sign({ departmentId, type: "department" }, JWT_SECRET, { expiresIn: "7d" });
}

export const authenticateUser: RequestHandler = (req, res, next) => {
  const token = req.headers.authorization?.split(" ")[1];

  if (!token) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET) as any;
    if (decoded.type !== "user") {
      res.status(401).json({ error: "Invalid token" });
      return;
    }
    req.userId = decoded.userId;
    next();
  } catch (error) {
    res.status(401).json({ error: "Invalid token" });
  }
};

export const authenticateDepartment: RequestHandler = (req, res, next) => {
  const token = req.headers.authorization?.split(" ")[1];

  if (!token) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET) as any;
    if (decoded.type !== "department") {
      res.status(401).json({ error: "Invalid token" });
      return;
    }
    req.departmentId = decoded.departmentId;
    next();
  } catch (error) {
    res.status(401).json({ error: "Invalid token" });
  }
};
