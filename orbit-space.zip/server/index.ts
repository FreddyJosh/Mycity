import "dotenv/config";
import express from "express";
import cors from "cors";
import { handleDemo } from "./routes/demo";
import complaintsRouter from "./routes/complaints";
import usersRouter from "./routes/users";
import departmentsRouter from "./routes/departments";
import { initializeDatabase } from "./config/database";

export function createServer() {
  const app = express();

  // Middleware
  app.use(cors());
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ extended: true, limit: "50mb" }));

  // Initialize database on startup
  initializeDatabase().catch((error) => {
    console.error("Failed to initialize database:", error);
  });

  // Example API routes
  app.get("/api/ping", (_req, res) => {
    const ping = process.env.PING_MESSAGE ?? "ping";
    res.json({ message: ping });
  });

  app.get("/api/demo", handleDemo);

  // API Routes
  app.use("/api/complaints", complaintsRouter);
  app.use("/api/users", usersRouter);
  app.use("/api/departments", departmentsRouter);

  return app;
}
