import pool from "../config/database";

export class OTP {
  static async create(email: string, otp: string) {
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

    // Remove existing OTP for this email
    await pool.execute("DELETE FROM otp_table WHERE email = ?", [email]);

    // Insert new OTP
    const [result] = await pool.execute(
      "INSERT INTO otp_table (email, otp, expires_at) VALUES (?, ?, ?)",
      [email, otp, expiresAt]
    );

    return result;
  }

  static async verify(email: string, otp: string) {
    const [rows] = await pool.execute(
      "SELECT * FROM otp_table WHERE email = ? AND otp = ? AND expires_at > NOW()",
      [email, otp]
    );

    if (rows?.[0]) {
      // Delete OTP after verification
      await pool.execute("DELETE FROM otp_table WHERE email = ? AND otp = ?", [email, otp]);
      return true;
    }

    return false;
  }

  static async deleteExpired() {
    await pool.execute("DELETE FROM otp_table WHERE expires_at < NOW()");
  }
}
