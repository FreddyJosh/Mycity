import pool from "../config/database";

export class Complaint {
  static getDepartmentForProblem(problemType: string): string {
    const departmentMap: { [key: string]: string } = {
      Pothole: "Roadways",
      "Garbage Issue": "Sanitary",
      "Broken Street Light": "Street Light",
      Waterlogging: "Drainage",
      "Illegal Dumping": "Sanitary",
      "Road Damage": "Roadways",
      "Sewage Problem": "Drainage",
    };
    return departmentMap[problemType] || "General";
  }

  static async create(
    userId: number,
    problemType: string,
    description: string,
    imageBefore: string,
    latitude: number,
    longitude: number
  ) {
    const departmentName = this.getDepartmentForProblem(problemType);

    // Get department ID
    const [deptRows] = await pool.execute("SELECT id FROM departments WHERE name = ?", [
      departmentName,
    ]);
    const departmentId = deptRows?.[0]?.id || null;

    const [result] = await pool.execute(
      `INSERT INTO complaints 
      (user_id, department_id, problem_type, description, image_before, latitude, longitude) 
      VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [userId, departmentId, problemType, description, imageBefore, latitude, longitude]
    );

    return result;
  }

  static async getAll() {
    const [rows] = await pool.execute(`
      SELECT c.*, u.username, d.name as department_name 
      FROM complaints c 
      LEFT JOIN users u ON c.user_id = u.id 
      LEFT JOIN departments d ON c.department_id = d.id
      ORDER BY c.created_at DESC
    `);
    return rows;
  }

  static async getByDepartment(departmentId: number) {
    const [rows] = await pool.execute(
      `SELECT c.*, u.username 
       FROM complaints c 
       LEFT JOIN users u ON c.user_id = u.id 
       WHERE c.department_id = ? 
       ORDER BY c.created_at DESC`,
      [departmentId]
    );
    return rows;
  }

  static async getById(id: number) {
    const [rows] = await pool.execute("SELECT * FROM complaints WHERE id = ?", [id]);
    return rows?.[0];
  }

  static async updateStatus(id: number, status: string, imageAfter?: string) {
    let query = "UPDATE complaints SET status = ?";
    const params: any[] = [status];

    if (imageAfter) {
      query += ", image_after = ?";
      params.push(imageAfter);
    }

    query += " WHERE id = ?";
    params.push(id);

    const [result] = await pool.execute(query, params);
    return result;
  }

  static async getByUser(userId: number) {
    const [rows] = await pool.execute(
      "SELECT * FROM complaints WHERE user_id = ? ORDER BY created_at DESC",
      [userId]
    );
    return rows;
  }
}
