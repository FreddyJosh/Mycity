import pool from "../config/database";

export class Department {
  static async findByName(name: string) {
    const [rows] = await pool.execute("SELECT * FROM departments WHERE name = ?", [name]);
    return rows?.[0];
  }

  static async findById(id: number) {
    const [rows] = await pool.execute("SELECT id, name, email FROM departments WHERE id = ?", [
      id,
    ]);
    return rows?.[0];
  }

  static async findByEmail(email: string) {
    const [rows] = await pool.execute("SELECT * FROM departments WHERE email = ?", [email]);
    return rows?.[0];
  }

  static async validatePassword(password: string, passwordHash: string): Promise<boolean> {
    // Simple comparison for mock passwords
    // In production, use bcrypt
    return password === passwordHash;
  }

  static async getAll() {
    const [rows] = await pool.execute("SELECT id, name, email FROM departments");
    return rows;
  }
}
