import pool from "../config/database";
import bcrypt from "bcryptjs";

export class User {
  static async findByUsername(username: string) {
    const [rows] = await pool.execute("SELECT * FROM users WHERE username = ?", [username]);
    return rows?.[0];
  }

  static async findByEmail(email: string) {
    const [rows] = await pool.execute("SELECT * FROM users WHERE email = ?", [email]);
    return rows?.[0];
  }

  static async findById(id: number) {
    const [rows] = await pool.execute("SELECT * FROM users WHERE id = ?", [id]);
    return rows?.[0];
  }

  static async create(username: string, email: string, password: string) {
    const passwordHash = await bcrypt.hash(password, 10);
    const [result] = await pool.execute(
      "INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)",
      [username, email, passwordHash]
    );
    return result;
  }

  static async validatePassword(password: string, passwordHash: string): Promise<boolean> {
    return bcrypt.compare(password, passwordHash);
  }

  static async getAllUsers() {
    const [rows] = await pool.execute("SELECT id, username, email, created_at FROM users");
    return rows;
  }
}
