/**
 * Shared code between client and server
 * Useful to share types between client and server
 * and/or small pure JS functions that can be used on both client and server
 */

// Auth
export interface LoginRequest {
  email: string;
  password: string;
}

export interface LoginResponse {
  success: boolean;
  token?: string;
  message: string;
}

// Complaint
export interface CreateComplaintRequest {
  userId?: string;
  beforeImage: string; // base64
  gpsLat: number;
  gpsLng: number;
  issueTypeAi?: string;
  severityAi?: string;
  suggestedDept?: string;
  confidence?: number;
}

export interface ComplaintResponse {
  id: number;
  userId: string;
  beforeImage: string;
  afterImage?: string;
  issueTypeAi: string;
  issueTypeAdmin?: string;
  severity: string;
  gpsLat: number;
  gpsLng: number;
  deptId?: number;
  status: string;
  createdAt: string;
  updatedAt: string;
}

// AI
export interface AIDetectionRequest {
  image: string; // base64
}

export interface AIDetectionResponse {
  issueType: string;
  severity: string;
  suggestedDepartment: string;
  confidence: number;
}

export interface AIComparisonRequest {
  beforeImage: string; // base64
  afterImage: string; // base64
}

export interface AIComparisonResponse {
  similarityScore: number;
  isMatch: boolean;
}

// Admin
export interface AdminApproveRequest {
  complaintId: number;
  issueType?: string;
  deptId?: number;
}

export interface AdminRejectRequest {
  complaintId: number;
  reason: string;
}

// Department
export interface DepartmentUpdateRequest {
  complaintId: number;
  status: string;
  afterImage?: string; // base64
}

export interface DemoResponse {
  message: string;
}
