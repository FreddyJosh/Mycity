import "dotenv/config";
import express from "express";
import cors from "cors";
import { handleDemo } from "./routes/demo";
import { handleLogin, handleRegister } from "./routes/auth";
import {
  handleCreateComplaint,
  handleGetUserComplaints,
  handleGetAllComplaints,
  handleGetComplaintById,
  handleUpdateComplaintStatus,
} from "./routes/complaints";
import { handleDetectIssue, handleCompareImages } from "./routes/ai";
import {
  handleGetPendingComplaints,
  handleGetApprovedComplaints,
  handleGetCompletedComplaints,
  handleApproveComplaint,
  handleRejectComplaint,
  handleAssignDepartment,
  handleVerifyCompletion,
} from "./routes/admin";
import {
  handleGetDepartmentComplaints,
  handleUploadAfterImage,
  handleUpdateComplaintProgress,
  handleGetDepartmentInfo,
} from "./routes/department";

export function createServer() {
  const app = express();

  // Middleware
  app.use(cors());
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ extended: true, limit: "50mb" }));

  // Example API routes
  app.get("/api/ping", (_req, res) => {
    const ping = process.env.PING_MESSAGE ?? "pong";
    res.json({ message: ping });
  });

  app.get("/api/demo", handleDemo);

  // Auth routes
  app.post("/api/auth/login", handleLogin);
  app.post("/api/auth/register", handleRegister);

  // Complaint routes
  app.post("/api/complaint/create", handleCreateComplaint);
  app.get("/api/complaint/user/:userId", handleGetUserComplaints);
  app.get("/api/complaint/all", handleGetAllComplaints);
  app.get("/api/complaint/:id", handleGetComplaintById);
  app.patch("/api/complaint/:id", handleUpdateComplaintStatus);

  // AI routes
  app.post("/api/ai/detect-issue", handleDetectIssue);
  app.post("/api/ai/compare", handleCompareImages);

  // Admin routes
  app.get("/api/admin/pending", handleGetPendingComplaints);
  app.get("/api/admin/approved", handleGetApprovedComplaints);
  app.get("/api/admin/completed", handleGetCompletedComplaints);
  app.post("/api/admin/approve", handleApproveComplaint);
  app.post("/api/admin/reject", handleRejectComplaint);
  app.post("/api/admin/assign-department", handleAssignDepartment);
  app.post("/api/admin/verify-completion", handleVerifyCompletion);

  // Department routes
  app.get("/api/department/complaints/:deptId", handleGetDepartmentComplaints);
  app.post("/api/department/upload-after-image", handleUploadAfterImage);
  app.patch("/api/department/update-status", handleUpdateComplaintProgress);
  app.get("/api/department/info/:deptId", handleGetDepartmentInfo);

  return app;
}
