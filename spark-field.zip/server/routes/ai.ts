import { RequestHandler } from "express";
import { AIDetectionRequest, AIDetectionResponse, AIComparisonResponse } from "@shared/api";

// Mock AI detection - in production, call HuggingFace API
const issueTypes = [
  "Pothole",
  "Garbage Accumulation",
  "Streetlight Failure",
  "Waterlogging",
  "Damaged Sidewalk",
  "Road Sign Missing",
];

const departments: { [key: string]: string } = {
  "Pothole": "Roads & Infrastructure",
  "Garbage Accumulation": "Sanitation Department",
  "Streetlight Failure": "Electricity Department",
  "Waterlogging": "Drainage Department",
  "Damaged Sidewalk": "Roads & Infrastructure",
  "Road Sign Missing": "Traffic Department",
};

const severities = ["Low", "Medium", "High"];

export const handleDetectIssue: RequestHandler = (req, res) => {
  const { image } = req.body as AIDetectionRequest;

  if (!image) {
    return res.status(400).json({
      success: false,
      message: "Image is required",
    });
  }

  // Simulate AI detection with random results
  const randomIssueType = issueTypes[Math.floor(Math.random() * issueTypes.length)];
  const randomSeverity = severities[Math.floor(Math.random() * severities.length)];
  const confidence = 0.85 + Math.random() * 0.15; // 0.85 - 1.0

  const response: AIDetectionResponse = {
    issueType: randomIssueType,
    severity: randomSeverity,
    suggestedDepartment: departments[randomIssueType] || "General",
    confidence: Math.round(confidence * 100) / 100,
  };

  res.json({
    success: true,
    data: response,
  });
};

export const handleCompareImages: RequestHandler = (req, res) => {
  const { beforeImage, afterImage } = req.body;

  if (!beforeImage || !afterImage) {
    return res.status(400).json({
      success: false,
      message: "Both images are required",
    });
  }

  // Simulate image comparison with random similarity score
  // In production, use CLIP or DINOv2 from HuggingFace
  const similarityScore = 0.3 + Math.random() * 0.4; // 0.3 - 0.7 (lower is better for before/after comparison)
  const isMatch = similarityScore > 0.5; // If images are too similar, they might be the same

  const response: AIComparisonResponse = {
    similarityScore: Math.round(similarityScore * 100) / 100,
    isMatch,
  };

  res.json({
    success: true,
    data: response,
  });
};

export const handleHuggingFaceDetection = async (
  imageBase64: string
): Promise<AIDetectionResponse> => {
  // In production, call HuggingFace API
  // const response = await fetch('https://api-inference.huggingface.co/models/facebook/detr-resnet-50', {
  //   headers: { Authorization: `Bearer ${process.env.HUGGINGFACE_API_KEY}` },
  //   method: 'POST',
  //   body: imageBase64,
  // });

  // For now, return mock result
  return {
    issueType: issueTypes[Math.floor(Math.random() * issueTypes.length)],
    severity: severities[Math.floor(Math.random() * severities.length)],
    suggestedDepartment: "General",
    confidence: 0.92,
  };
};

export const handleHuggingFaceComparison = async (
  beforeImage: string,
  afterImage: string
): Promise<AIComparisonResponse> => {
  // In production, call HuggingFace API with CLIP model
  // const response = await fetch('https://api-inference.huggingface.co/models/openai/clip-vit-base-patch32', {
  //   headers: { Authorization: `Bearer ${process.env.HUGGINGFACE_API_KEY}` },
  //   method: 'POST',
  //   body: JSON.stringify({ images: [beforeImage, afterImage] }),
  // });

  // For now, return mock result
  return {
    similarityScore: 0.35,
    isMatch: false,
  };
};
