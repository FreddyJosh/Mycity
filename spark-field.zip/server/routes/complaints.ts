import { RequestHandler } from "express";
import { CreateComplaintRequest, ComplaintResponse } from "@shared/api";

// Mock complaint database
let complaints: ComplaintResponse[] = [];
let complaintId = 1;

export const handleCreateComplaint: RequestHandler = (req, res) => {
  const {
    userId,
    beforeImage,
    gpsLat,
    gpsLng,
    issueTypeAi,
    severityAi,
    suggestedDept,
    confidence,
  } = req.body as CreateComplaintRequest;

  if (!beforeImage || gpsLat === undefined || gpsLng === undefined) {
    return res.status(400).json({
      success: false,
      message: "Image and GPS coordinates are required",
    });
  }

  const complaint: ComplaintResponse = {
    id: complaintId++,
    userId: userId || "anonymous",
    beforeImage,
    issueTypeAi: issueTypeAi || "Unknown",
    severity: severityAi || "Medium",
    gpsLat,
    gpsLng,
    deptId: undefined,
    status: "pending_admin",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  complaints.push(complaint);

  res.status(201).json({
    success: true,
    data: complaint,
    message: "Complaint created successfully",
  });
};

export const handleGetUserComplaints: RequestHandler = (req, res) => {
  const { userId } = req.params;

  const userComplaints = complaints.filter((c) => c.userId === userId || userId === "all");

  res.json({
    success: true,
    data: userComplaints,
  });
};

export const handleGetAllComplaints: RequestHandler = (req, res) => {
  res.json({
    success: true,
    data: complaints,
  });
};

export const handleGetComplaintById: RequestHandler = (req, res) => {
  const { id } = req.params;
  const complaint = complaints.find((c) => c.id === Number(id));

  if (!complaint) {
    return res.status(404).json({
      success: false,
      message: "Complaint not found",
    });
  }

  res.json({
    success: true,
    data: complaint,
  });
};

export const handleUpdateComplaintStatus: RequestHandler = (req, res) => {
  const { id } = req.params;
  const { status, afterImage, issueTypeAdmin, deptId } = req.body;

  const complaint = complaints.find((c) => c.id === Number(id));

  if (!complaint) {
    return res.status(404).json({
      success: false,
      message: "Complaint not found",
    });
  }

  if (status) complaint.status = status;
  if (afterImage) complaint.afterImage = afterImage;
  if (issueTypeAdmin) complaint.issueTypeAdmin = issueTypeAdmin;
  if (deptId) complaint.deptId = deptId;
  complaint.updatedAt = new Date().toISOString();

  res.json({
    success: true,
    data: complaint,
    message: "Complaint updated successfully",
  });
};
