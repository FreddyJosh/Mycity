import { RequestHandler } from "express";
import { LoginRequest, LoginResponse } from "@shared/api";

// Mock user database - in production use real DB
const users: { [key: string]: { id: string; email: string; password: string; role: string } } = {
  "admin@mycity.gov": { id: "1", email: "admin@mycity.gov", password: "admin123", role: "admin" },
  "roads@mycity.gov": { id: "2", email: "roads@mycity.gov", password: "dept123", role: "department" },
  "citizen@example.com": { id: "3", email: "citizen@example.com", password: "citizen123", role: "citizen" },
};

export const handleLogin: RequestHandler = (req, res) => {
  const { email, password } = req.body as LoginRequest;

  if (!email || !password) {
    return res.status(400).json({
      success: false,
      message: "Email and password are required",
    });
  }

  const user = users[email];
  if (!user || user.password !== password) {
    return res.status(401).json({
      success: false,
      message: "Invalid credentials",
    });
  }

  // In production, generate JWT token
  const response: LoginResponse = {
    success: true,
    token: `token_${user.id}_${Date.now()}`,
    message: "Login successful",
  };

  res.json(response);
};

export const handleRegister: RequestHandler = (req, res) => {
  const { email, password, name } = req.body;

  if (!email || !password) {
    return res.status(400).json({
      success: false,
      message: "Email and password are required",
    });
  }

  if (users[email]) {
    return res.status(409).json({
      success: false,
      message: "User already exists",
    });
  }

  const newUserId = String(Object.keys(users).length + 1);
  users[email] = {
    id: newUserId,
    email,
    password,
    role: "citizen",
  };

  res.status(201).json({
    success: true,
    token: `token_${newUserId}_${Date.now()}`,
    message: "Registration successful",
  });
};
