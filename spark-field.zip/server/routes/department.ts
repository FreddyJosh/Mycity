import { RequestHandler } from "express";
import { DepartmentUpdateRequest } from "@shared/api";

// Mock department database
const departments: { [key: string]: { id: string; name: string; email: string } } = {
  "1": { id: "1", name: "Roads & Infrastructure", email: "roads@mycity.gov" },
  "2": { id: "2", name: "Sanitation Department", email: "sanitation@mycity.gov" },
  "3": { id: "3", name: "Electricity Department", email: "electricity@mycity.gov" },
  "4": { id: "4", name: "Drainage Department", email: "drainage@mycity.gov" },
};

// Mock complaints assigned to departments
let departmentComplaints: any[] = [
  {
    id: 1,
    deptId: "1",
    type: "Pothole",
    location: "Main Street",
    severity: "High",
    status: "assigned",
    beforeImage: "",
    submittedDate: "2024-01-15",
  },
  {
    id: 2,
    deptId: "3",
    type: "Streetlight",
    location: "East Road",
    severity: "Low",
    status: "in_progress",
    beforeImage: "",
    submittedDate: "2024-01-12",
  },
];

export const handleGetDepartmentComplaints: RequestHandler = (req, res) => {
  const { deptId } = req.params;

  const complaints = departmentComplaints.filter((c) => c.deptId === deptId);

  res.json({
    success: true,
    data: complaints,
  });
};

export const handleUploadAfterImage: RequestHandler = (req, res) => {
  const { complaintId, afterImage } = req.body;

  const complaint = departmentComplaints.find((c) => c.id === Number(complaintId));

  if (!complaint) {
    return res.status(404).json({
      success: false,
      message: "Complaint not found",
    });
  }

  complaint.afterImage = afterImage;
  complaint.uploadedAt = new Date().toISOString();

  res.json({
    success: true,
    data: complaint,
    message: "After image uploaded successfully",
  });
};

export const handleUpdateComplaintProgress: RequestHandler = (req, res) => {
  const { complaintId, status } = req.body as DepartmentUpdateRequest;

  const complaint = departmentComplaints.find((c) => c.id === Number(complaintId));

  if (!complaint) {
    return res.status(404).json({
      success: false,
      message: "Complaint not found",
    });
  }

  const validStatuses = ["assigned", "in_progress", "completed"];
  if (!validStatuses.includes(status)) {
    return res.status(400).json({
      success: false,
      message: "Invalid status",
    });
  }

  complaint.status = status;
  complaint.updatedAt = new Date().toISOString();

  res.json({
    success: true,
    data: complaint,
    message: "Complaint status updated successfully",
  });
};

export const handleGetDepartmentInfo: RequestHandler = (req, res) => {
  const { deptId } = req.params;

  const dept = departments[deptId];

  if (!dept) {
    return res.status(404).json({
      success: false,
      message: "Department not found",
    });
  }

  res.json({
    success: true,
    data: dept,
  });
};
