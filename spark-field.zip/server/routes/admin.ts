import { RequestHandler } from "express";
import { AdminApproveRequest, AdminRejectRequest } from "@shared/api";

// Mock data - in production use real DB
let complaints: any[] = [
  {
    id: 1,
    type: "Pothole",
    severity: "High",
    status: "pending_admin",
    location: "Main Street, Block 45",
  },
  {
    id: 2,
    type: "Garbage",
    severity: "Medium",
    status: "pending_admin",
    location: "Park Avenue",
  },
];

export const handleGetPendingComplaints: RequestHandler = (req, res) => {
  const pending = complaints.filter((c) => c.status === "pending_admin");

  res.json({
    success: true,
    data: pending,
  });
};

export const handleGetApprovedComplaints: RequestHandler = (req, res) => {
  const approved = complaints.filter((c) => c.status === "approved");

  res.json({
    success: true,
    data: approved,
  });
};

export const handleGetCompletedComplaints: RequestHandler = (req, res) => {
  const completed = complaints.filter((c) => c.status === "completed");

  res.json({
    success: true,
    data: completed,
  });
};

export const handleApproveComplaint: RequestHandler = (req, res) => {
  const { complaintId, issueType, deptId } = req.body as AdminApproveRequest;

  const complaint = complaints.find((c) => c.id === complaintId);

  if (!complaint) {
    return res.status(404).json({
      success: false,
      message: "Complaint not found",
    });
  }

  complaint.status = "approved";
  if (issueType) complaint.issueTypeAdmin = issueType;
  if (deptId) complaint.deptId = deptId;

  res.json({
    success: true,
    data: complaint,
    message: "Complaint approved successfully",
  });
};

export const handleRejectComplaint: RequestHandler = (req, res) => {
  const { complaintId, reason } = req.body as AdminRejectRequest;

  const complaint = complaints.find((c) => c.id === complaintId);

  if (!complaint) {
    return res.status(404).json({
      success: false,
      message: "Complaint not found",
    });
  }

  complaint.status = "rejected";
  complaint.rejectionReason = reason;

  res.json({
    success: true,
    data: complaint,
    message: "Complaint rejected",
  });
};

export const handleAssignDepartment: RequestHandler = (req, res) => {
  const { complaintId, deptId } = req.body;

  const complaint = complaints.find((c) => c.id === complaintId);

  if (!complaint) {
    return res.status(404).json({
      success: false,
      message: "Complaint not found",
    });
  }

  complaint.deptId = deptId;
  complaint.status = "assigned";

  res.json({
    success: true,
    data: complaint,
    message: "Department assigned successfully",
  });
};

export const handleVerifyCompletion: RequestHandler = (req, res) => {
  const { complaintId, similarityScore } = req.body;

  const complaint = complaints.find((c) => c.id === complaintId);

  if (!complaint) {
    return res.status(404).json({
      success: false,
      message: "Complaint not found",
    });
  }

  complaint.status = "completed";
  complaint.similarityScore = similarityScore;
  complaint.completedAt = new Date().toISOString();

  res.json({
    success: true,
    data: complaint,
    message: "Complaint marked as completed",
  });
};
