import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { Camera, MapPin, AlertCircle } from 'lucide-react';

export default function CitizenHome() {
  const mapContainer = useRef<HTMLDivElement>(null);
  const [complaints, setComplaints] = useState<any[]>([]);

  useEffect(() => {
    // Dynamically load Leaflet library
    if (!document.querySelector('link[href*="leaflet"]')) {
      const link = document.createElement('link');
      link.href = 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css';
      link.rel = 'stylesheet';
      document.head.appendChild(link);

      const script = document.createElement('script');
      script.src = 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js';
      script.async = true;
      script.onload = initializeMap;
      document.head.appendChild(script);
    } else {
      setTimeout(initializeMap, 100);
    }
  }, []);

  const initializeMap = () => {
    if (!mapContainer.current) return;

    const L = (window as any).L;
    if (!L) return;

    // Initialize map centered on a default location
    const map = L.map(mapContainer.current).setView([28.6139, 77.2090], 12);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap contributors',
      maxZoom: 19,
    }).addTo(map);

    // Sample data - in production, fetch from API
    const sampleComplaints = [
      {
        id: 1,
        lat: 28.6139,
        lng: 77.2090,
        status: 'pending',
        type: 'pothole',
        title: 'Pothole on Main Road',
      },
      {
        id: 2,
        lat: 28.6250,
        lng: 77.2300,
        status: 'approved',
        type: 'garbage',
        title: 'Garbage Accumulation',
      },
      {
        id: 3,
        lat: 28.6000,
        lng: 77.2000,
        status: 'completed',
        type: 'streetlight',
        title: 'Streetlight Fixed',
      },
    ];

    setComplaints(sampleComplaints);

    // Color mapping for different statuses
    const statusColors: { [key: string]: string } = {
      pending: '#FFA500',
      approved: '#1976F3',
      completed: '#28D762',
    };

    // Add markers for each complaint
    sampleComplaints.forEach((complaint) => {
      const circleMarker = L.circleMarker(
        [complaint.lat, complaint.lng],
        {
          radius: 12,
          fillColor: statusColors[complaint.status],
          color: '#fff',
          weight: 2,
          opacity: 1,
          fillOpacity: 0.8,
        }
      ).addTo(map);

      const popupContent = `
        <div class="p-3 rounded-lg bg-white shadow-md">
          <h3 class="font-semibold text-gray-900 mb-1">${complaint.title}</h3>
          <p class="text-sm text-gray-600 mb-2">Type: ${complaint.type}</p>
          <p class="text-xs font-medium text-gray-500">Status: <span class="capitalize">${complaint.status}</span></p>
        </div>
      `;

      circleMarker.bindPopup(popupContent);
    });
  };

  return (
    <div className="h-screen w-full flex flex-col bg-gradient-to-b from-blue-50 to-white">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-400 rounded-lg flex items-center justify-center">
              <MapPin className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900">MyCity</h1>
          </div>
          <nav className="flex items-center gap-4">
            <Link
              to="/citizen/dashboard"
              className="text-sm font-medium text-gray-700 hover:text-blue-600 transition"
            >
              My Complaints
            </Link>
            <Link
              to="/admin/login"
              className="text-sm font-medium text-gray-700 hover:text-blue-600 transition"
            >
              Admin
            </Link>
            <Link
              to="/department/login"
              className="text-sm font-medium text-gray-700 hover:text-blue-600 transition"
            >
              Department
            </Link>
          </nav>
        </div>
      </header>

      {/* Map Container */}
      <div className="flex-1 relative">
        <div ref={mapContainer} className="w-full h-full rounded-none" style={{ background: '#f0f0f0' }} />

        {/* Legend */}
        <div className="absolute bottom-6 left-6 bg-white rounded-xl shadow-lg p-4 max-w-xs">
          <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-blue-600" />
            Complaint Status
          </h3>
          <div className="space-y-2">
            <div className="flex items-center gap-3">
              <div className="w-3 h-3 rounded-full bg-orange-500"></div>
              <span className="text-sm text-gray-700">Pending Review</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-3 h-3 rounded-full bg-blue-600"></div>
              <span className="text-sm text-gray-700">Approved</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-3 h-3 rounded-full bg-green-500"></div>
              <span className="text-sm text-gray-700">Completed</span>
            </div>
          </div>
        </div>

        {/* Floating Camera Button */}
        <Link
          to="/camera"
          className="absolute bottom-6 right-6 w-14 h-14 bg-gradient-to-br from-blue-600 to-blue-500 text-white rounded-full flex items-center justify-center shadow-lg hover:shadow-xl hover:scale-110 transition-all duration-300 group"
        >
          <Camera className="w-7 h-7 group-hover:scale-110 transition-transform" />
        </Link>
      </div>
    </div>
  );
}
