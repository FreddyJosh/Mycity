import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Clock, CheckCircle, Upload } from 'lucide-react';

interface Complaint {
  id: number;
  type: string;
  location: string;
  severity: string;
  approvedDate: string;
  status: string;
  beforeImage?: string;
}

export default function DepartmentDashboard() {
  const [selectedComplaint, setSelectedComplaint] = useState<Complaint | null>(null);
  const [uploadingFile, setUploadingFile] = useState<File | null>(null);

  const complaints: Complaint[] = [
    {
      id: 1,
      type: 'Pothole',
      location: 'Main Street, Block 45',
      severity: 'High',
      approvedDate: '2024-01-15',
      status: 'assigned',
      beforeImage: 'https://via.placeholder.com/300x200?text=Pothole',
    },
    {
      id: 2,
      type: 'Streetlight Failure',
      location: 'East Road, Zone 5',
      severity: 'Low',
      approvedDate: '2024-01-12',
      status: 'in_progress',
      beforeImage: 'https://via.placeholder.com/300x200?text=Light',
    },
  ];

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.[0]) {
      setUploadingFile(e.target.files[0]);
    }
  };

  const handleSubmitCompletion = () => {
    console.log('Submitting completion with file:', uploadingFile);
    // In production, call API
    setUploadingFile(null);
    setSelectedComplaint(null);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link
              to="/"
              className="flex items-center gap-2 text-green-600 hover:text-green-700 transition"
            >
              <ArrowLeft className="w-5 h-5" />
            </Link>
            <h1 className="text-2xl font-bold text-gray-900">Assigned Complaints</h1>
          </div>
          <Link
            to="/"
            className="text-sm font-medium text-gray-700 hover:text-green-600 transition"
          >
            Logout
          </Link>
        </div>
      </header>

      {/* Content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        {selectedComplaint ? (
          // Detail View
          <div className="bg-white rounded-xl shadow-md border border-gray-200 p-8">
            <button
              onClick={() => {
                setSelectedComplaint(null);
                setUploadingFile(null);
              }}
              className="flex items-center gap-2 text-green-600 hover:text-green-700 transition mb-6"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to List</span>
            </button>

            <div className="grid grid-cols-2 gap-8 mb-8">
              {/* Before Image */}
              <div>
                <h3 className="text-sm font-semibold text-gray-500 mb-3 uppercase">
                  Before Image
                </h3>
                <img
                  src={selectedComplaint.beforeImage}
                  alt="Before"
                  className="w-full rounded-lg border-2 border-gray-200"
                />
              </div>

              {/* After Image Upload */}
              <div>
                <h3 className="text-sm font-semibold text-gray-500 mb-3 uppercase">
                  After Image
                </h3>
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 flex items-center justify-center bg-gray-50 hover:bg-gray-100 transition cursor-pointer">
                  {uploadingFile ? (
                    <div className="text-center">
                      <CheckCircle className="w-8 h-8 text-green-600 mx-auto mb-2" />
                      <p className="text-sm font-medium text-gray-900">{uploadingFile.name}</p>
                    </div>
                  ) : (
                    <label className="cursor-pointer text-center">
                      <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                      <p className="text-sm font-medium text-gray-700">Click to upload</p>
                      <p className="text-xs text-gray-500">PNG, JPG up to 5MB</p>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleFileSelect}
                        className="hidden"
                      />
                    </label>
                  )}
                </div>
              </div>
            </div>

            {/* Complaint Details */}
            <div className="bg-gray-50 rounded-lg p-6 mb-8">
              <div className="grid grid-cols-2 gap-8">
                <div>
                  <p className="text-sm font-semibold text-gray-500 mb-2">ISSUE TYPE</p>
                  <p className="text-lg font-bold text-gray-900">{selectedComplaint.type}</p>
                </div>
                <div>
                  <p className="text-sm font-semibold text-gray-500 mb-2">SEVERITY</p>
                  <p className="text-lg font-bold text-gray-900">{selectedComplaint.severity}</p>
                </div>
                <div>
                  <p className="text-sm font-semibold text-gray-500 mb-2">LOCATION</p>
                  <p className="text-lg font-bold text-gray-900">{selectedComplaint.location}</p>
                </div>
                <div>
                  <p className="text-sm font-semibold text-gray-500 mb-2">STATUS</p>
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-yellow-600" />
                    <p className="text-lg font-bold text-gray-900 capitalize">{selectedComplaint.status}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-4">
              <button
                onClick={() => {
                  setSelectedComplaint(null);
                  setUploadingFile(null);
                }}
                className="flex-1 px-6 py-3 bg-gray-200 text-gray-900 rounded-lg hover:bg-gray-300 transition font-medium"
              >
                Cancel
              </button>
              <button
                onClick={handleSubmitCompletion}
                disabled={!uploadingFile}
                className="flex-1 px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition font-medium disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                <CheckCircle className="w-5 h-5" />
                Mark as Complete
              </button>
            </div>
          </div>
        ) : (
          // List View
          <div className="grid gap-4">
            {complaints.map((complaint) => (
              <button
                key={complaint.id}
                onClick={() => setSelectedComplaint(complaint)}
                className="bg-white rounded-lg border border-gray-200 p-6 hover:shadow-lg transition text-left"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="text-lg font-bold text-gray-900 mb-2">{complaint.type}</h3>
                    <p className="text-gray-600 mb-3">{complaint.location}</p>
                    <div className="flex gap-4">
                      <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                        complaint.severity === 'High'
                          ? 'bg-red-100 text-red-800'
                          : complaint.severity === 'Medium'
                          ? 'bg-yellow-100 text-yellow-800'
                          : 'bg-blue-100 text-blue-800'
                      }`}>
                        {complaint.severity}
                      </span>
                      <span className="text-sm text-gray-500">{complaint.approvedDate}</span>
                      <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                        complaint.status === 'in_progress'
                          ? 'bg-yellow-100 text-yellow-800'
                          : 'bg-blue-100 text-blue-800'
                      }`}>
                        {complaint.status === 'in_progress' ? 'In Progress' : 'Assigned'}
                      </span>
                    </div>
                  </div>
                  <Clock className="w-5 h-5 text-gray-400 flex-shrink-0" />
                </div>
              </button>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
