import { Link } from 'react-router-dom';
import { ArrowLeft, MapPin, Clock, CheckCircle, AlertCircle } from 'lucide-react';

export default function CitizenDashboard() {
  const complaints = [
    {
      id: 1,
      type: 'Pothole',
      location: 'Main Street, Block 45',
      status: 'pending',
      submittedDate: '2024-01-15',
      severity: 'High',
    },
    {
      id: 2,
      type: 'Garbage Accumulation',
      location: 'Park Avenue, Sector 8',
      status: 'approved',
      submittedDate: '2024-01-12',
      severity: 'Medium',
    },
    {
      id: 3,
      type: 'Streetlight Failure',
      location: 'East Road, Zone 5',
      status: 'completed',
      submittedDate: '2024-01-08',
      severity: 'Low',
    },
  ];

  const statusColors: { [key: string]: { bg: string; text: string; icon: any } } = {
    pending: {
      bg: 'bg-orange-100',
      text: 'text-orange-800',
      icon: Clock,
    },
    approved: {
      bg: 'bg-blue-100',
      text: 'text-blue-800',
      icon: AlertCircle,
    },
    completed: {
      bg: 'bg-green-100',
      text: 'text-green-800',
      icon: CheckCircle,
    },
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center gap-4">
          <Link
            to="/"
            className="flex items-center gap-2 text-blue-600 hover:text-blue-700 transition"
          >
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <h1 className="text-2xl font-bold text-gray-900">My Complaints</h1>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid gap-6">
          {complaints.map((complaint) => {
            const StatusIcon = statusColors[complaint.status].icon;
            return (
              <div
                key={complaint.id}
                className="bg-white rounded-xl shadow-md border border-gray-200 overflow-hidden hover:shadow-lg transition"
              >
                <div className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="text-xl font-bold text-gray-900 mb-2">
                        {complaint.type}
                      </h3>
                      <div className="flex items-center gap-2 text-gray-600">
                        <MapPin className="w-4 h-4 flex-shrink-0" />
                        <p className="text-sm">{complaint.location}</p>
                      </div>
                    </div>
                    <div
                      className={`flex items-center gap-2 px-3 py-1.5 rounded-full font-medium ${
                        statusColors[complaint.status].bg
                      } ${statusColors[complaint.status].text}`}
                    >
                      <StatusIcon className="w-4 h-4" />
                      <span className="text-sm capitalize">{complaint.status}</span>
                    </div>
                  </div>

                  <div className="flex gap-6 pt-4 border-t border-gray-200">
                    <div>
                      <p className="text-xs font-medium text-gray-500 mb-1">SUBMITTED</p>
                      <p className="text-sm font-semibold text-gray-900">{complaint.submittedDate}</p>
                    </div>
                    <div>
                      <p className="text-xs font-medium text-gray-500 mb-1">SEVERITY</p>
                      <p className="text-sm font-semibold text-gray-900">{complaint.severity}</p>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {complaints.length === 0 && (
          <div className="text-center py-12">
            <AlertCircle className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No Complaints Yet</h3>
            <p className="text-gray-600 mb-6">Start reporting issues in your city</p>
            <Link
              to="/camera"
              className="inline-block px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition font-medium"
            >
              Report New Issue
            </Link>
          </div>
        )}
      </main>
    </div>
  );
}
