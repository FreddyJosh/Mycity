import { useState, useRef, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Camera, ArrowLeft, CheckCircle, AlertCircle } from 'lucide-react';

type CaptureStep = 'camera' | 'scanning' | 'confirmation';

interface AIDetection {
  issueType: string;
  severity: string;
  suggestedDepartment: string;
  confidence: number;
}

export default function CameraCapture() {
  const [step, setStep] = useState<CaptureStep>('camera');
  const [photo, setPhoto] = useState<string | null>(null);
  const [aiResult, setAiResult] = useState<AIDetection | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (step === 'camera' && !photo) {
      startCamera();
    }
  }, [step, photo]);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (error) {
      console.error('Error accessing camera:', error);
    }
  };

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const context = canvasRef.current.getContext('2d');
      if (context) {
        context.drawImage(videoRef.current, 0, 0, canvasRef.current.width, canvasRef.current.height);
        const photoData = canvasRef.current.toDataURL('image/jpeg');
        setPhoto(photoData);
        // Stop video stream
        if (videoRef.current.srcObject) {
          (videoRef.current.srcObject as MediaStream).getTracks().forEach(track => track.stop());
        }
        simulateAIDetection();
      }
    }
  };

  const simulateAIDetection = () => {
    setStep('scanning');
    // Simulate AI detection delay
    setTimeout(() => {
      setAiResult({
        issueType: 'Pothole',
        severity: 'High',
        suggestedDepartment: 'Roads & Infrastructure',
        confidence: 0.94,
      });
      setStep('confirmation');
    }, 2000);
  };

  const retakePhoto = () => {
    setPhoto(null);
    setAiResult(null);
    setStep('camera');
    startCamera();
  };

  const submitComplaint = async () => {
    // In production, send to backend API
    console.log('Submitting complaint with photo and AI result:', { photo, aiResult });
    // Show success and redirect
    setTimeout(() => {
      window.location.href = '/citizen/dashboard';
    }, 1000);
  };

  return (
    <div className="h-screen w-full bg-gray-900 flex flex-col">
      {/* Header */}
      <header className="bg-black/50 border-b border-gray-800 backdrop-blur">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <Link
            to="/"
            className="flex items-center gap-2 text-white hover:text-blue-400 transition"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Back</span>
          </Link>
          <h1 className="text-xl font-bold text-white">Report Issue</h1>
          <div className="w-20"></div>
        </div>
      </header>

      {/* Camera Step */}
      {step === 'camera' && (
        <div className="flex-1 flex flex-col items-center justify-center p-4">
          <div className="w-full max-w-md aspect-square bg-black rounded-3xl overflow-hidden shadow-2xl border-4 border-blue-600/30">
            <video
              ref={videoRef}
              autoPlay
              playsInline
              className="w-full h-full object-cover"
            />
          </div>
          <canvas ref={canvasRef} width={400} height={400} className="hidden" />

          <div className="mt-8 flex gap-4">
            <button
              onClick={retakePhoto}
              className="px-6 py-3 bg-gray-700 text-white rounded-lg hover:bg-gray-600 transition font-medium"
            >
              Cancel
            </button>
            <button
              onClick={capturePhoto}
              className="px-8 py-3 bg-gradient-to-r from-blue-600 to-blue-500 text-white rounded-lg hover:from-blue-700 hover:to-blue-600 transition font-medium flex items-center gap-2 shadow-lg"
            >
              <Camera className="w-5 h-5" />
              Capture Photo
            </button>
          </div>

          <p className="text-gray-400 text-center mt-6 text-sm max-w-xs">
            Position the issue clearly in the frame. Ensure good lighting for better AI detection.
          </p>
        </div>
      )}

      {/* Scanning Step */}
      {step === 'scanning' && (
        <div className="flex-1 flex flex-col items-center justify-center p-4">
          <div className="w-full max-w-md aspect-square bg-gradient-to-br from-gray-800 to-black rounded-3xl overflow-hidden shadow-2xl border-4 border-blue-600/30 flex items-center justify-center">
            <img src={photo!} alt="Captured" className="w-full h-full object-cover" />
          </div>

          <div className="mt-12 text-center">
            <div className="inline-block">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-blue-600 border-r-2 border-blue-500 mb-4"></div>
            </div>
            <h2 className="text-2xl font-bold text-white mb-2">Analyzing Image...</h2>
            <p className="text-gray-400">
              Our AI is detecting the issue type and severity level
            </p>
          </div>
        </div>
      )}

      {/* Confirmation Step */}
      {step === 'confirmation' && aiResult && (
        <div className="flex-1 flex flex-col items-center justify-center p-4 overflow-y-auto">
          <div className="w-full max-w-2xl">
            {/* Photo Display */}
            <div className="mb-6">
              <div className="w-full aspect-video bg-black rounded-2xl overflow-hidden shadow-xl border-2 border-gray-700">
                <img src={photo!} alt="Captured" className="w-full h-full object-cover" />
              </div>
            </div>

            {/* AI Results Card */}
            <div className="bg-gradient-to-br from-gray-800 to-gray-900 rounded-2xl p-8 mb-6 border border-gray-700 shadow-xl">
              <div className="flex items-center gap-3 mb-6">
                <CheckCircle className="w-7 h-7 text-green-400" />
                <h3 className="text-xl font-bold text-white">AI Detection Complete</h3>
              </div>

              <div className="space-y-4">
                <div className="bg-black/40 rounded-lg p-4">
                  <p className="text-gray-400 text-sm font-medium mb-1">Issue Type</p>
                  <p className="text-white text-lg font-semibold">{aiResult.issueType}</p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-black/40 rounded-lg p-4">
                    <p className="text-gray-400 text-sm font-medium mb-1">Severity Level</p>
                    <p className="text-white text-lg font-semibold">{aiResult.severity}</p>
                  </div>
                  <div className="bg-black/40 rounded-lg p-4">
                    <p className="text-gray-400 text-sm font-medium mb-1">Confidence</p>
                    <p className="text-white text-lg font-semibold">{(aiResult.confidence * 100).toFixed(0)}%</p>
                  </div>
                </div>

                <div className="bg-black/40 rounded-lg p-4">
                  <p className="text-gray-400 text-sm font-medium mb-1">Suggested Department</p>
                  <p className="text-white text-lg font-semibold">{aiResult.suggestedDepartment}</p>
                </div>
              </div>
            </div>

            {/* Info Box */}
            <div className="bg-blue-950/50 border border-blue-400/30 rounded-lg p-4 mb-6 flex gap-3">
              <AlertCircle className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-blue-200">
                Please review the AI-detected information. You can edit the issue type if needed.
              </p>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-4">
              <button
                onClick={retakePhoto}
                className="flex-1 px-6 py-3 bg-gray-700 text-white rounded-lg hover:bg-gray-600 transition font-medium"
              >
                Retake Photo
              </button>
              <button
                onClick={submitComplaint}
                className="flex-1 px-6 py-3 bg-gradient-to-r from-green-600 to-green-500 text-white rounded-lg hover:from-green-700 hover:to-green-600 transition font-medium shadow-lg"
              >
                Submit Complaint
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
