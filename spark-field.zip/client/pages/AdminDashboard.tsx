import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, CheckCircle, Clock, XCircle, Image as ImageIcon } from 'lucide-react';
import ImageComparison from '@/components/ImageComparison';

type TabType = 'pending' | 'approved' | 'completed';

interface Complaint {
  id: number;
  type: string;
  severity: string;
  location: string;
  submittedDate: string;
  beforeImage?: string;
  afterImage?: string;
  status: string;
  department?: string;
}

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState<TabType>('pending');
  const [selectedComplaint, setSelectedComplaint] = useState<Complaint | null>(null);

  const complaints: { [key in TabType]: Complaint[] } = {
    pending: [
      {
        id: 1,
        type: 'Pothole',
        severity: 'High',
        location: 'Main Street, Block 45',
        submittedDate: '2024-01-15',
        status: 'pending_admin',
      },
      {
        id: 2,
        type: 'Garbage Accumulation',
        severity: 'Medium',
        location: 'Park Avenue, Sector 8',
        submittedDate: '2024-01-14',
        status: 'pending_admin',
      },
    ],
    approved: [
      {
        id: 3,
        type: 'Streetlight Failure',
        severity: 'Low',
        location: 'East Road, Zone 5',
        submittedDate: '2024-01-12',
        department: 'Electricity Department',
        status: 'approved',
      },
    ],
    completed: [
      {
        id: 4,
        type: 'Waterlogging',
        severity: 'High',
        location: 'West Avenue, Block 12',
        submittedDate: '2024-01-08',
        department: 'Drainage Department',
        beforeImage: 'https://via.placeholder.com/300x200?text=Before',
        afterImage: 'https://via.placeholder.com/300x200?text=After',
        status: 'completed',
      },
    ],
  };

  const currentComplaints = complaints[activeTab];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link
              to="/"
              className="flex items-center gap-2 text-blue-600 hover:text-blue-700 transition"
            >
              <ArrowLeft className="w-5 h-5" />
            </Link>
            <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>
          </div>
          <Link
            to="/"
            className="text-sm font-medium text-gray-700 hover:text-blue-600 transition"
          >
            Logout
          </Link>
        </div>
      </header>

      {/* Tabs */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex gap-8">
            {['pending', 'approved', 'completed'].map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab as TabType)}
                className={`py-4 px-1 border-b-2 font-medium text-sm transition ${
                  activeTab === tab
                    ? 'border-blue-600 text-blue-600'
                    : 'border-transparent text-gray-600 hover:text-gray-900'
                }`}
              >
                {tab === 'pending' && `Pending (${complaints.pending.length})`}
                {tab === 'approved' && `Approved (${complaints.approved.length})`}
                {tab === 'completed' && `Completed (${complaints.completed.length})`}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        {selectedComplaint ? (
          // Detail View
          <div className="bg-white rounded-xl shadow-md border border-gray-200 p-8">
            <button
              onClick={() => setSelectedComplaint(null)}
              className="flex items-center gap-2 text-blue-600 hover:text-blue-700 transition mb-6"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to List</span>
            </button>

            <div className="mb-8">
              {selectedComplaint.afterImage ? (
                <>
                  <h3 className="text-sm font-semibold text-gray-500 mb-3 uppercase">
                    Before & After Comparison
                  </h3>
                  <ImageComparison
                    beforeImage={selectedComplaint.beforeImage || 'https://via.placeholder.com/800x600?text=Before'}
                    afterImage={selectedComplaint.afterImage}
                    beforeLabel="Before"
                    afterLabel="After"
                  />
                </>
              ) : (
                <div className="grid grid-cols-2 gap-8">
                  {/* Before Image */}
                  <div>
                    <h3 className="text-sm font-semibold text-gray-500 mb-3 uppercase">
                      Before Image
                    </h3>
                    <div className="bg-gray-100 rounded-lg aspect-video flex items-center justify-center border-2 border-gray-300">
                      {selectedComplaint.beforeImage ? (
                        <img
                          src={selectedComplaint.beforeImage}
                          alt="Before"
                          className="w-full h-full object-cover rounded-lg"
                        />
                      ) : (
                        <div className="flex flex-col items-center gap-2 text-gray-400">
                          <ImageIcon className="w-8 h-8" />
                          <span className="text-sm">No image</span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* After Image */}
                  <div>
                    <h3 className="text-sm font-semibold text-gray-500 mb-3 uppercase">
                      After Image
                    </h3>
                    <div className="bg-gray-100 rounded-lg aspect-video flex items-center justify-center border-2 border-gray-300">
                      <div className="flex flex-col items-center gap-2 text-gray-400">
                        <ImageIcon className="w-8 h-8" />
                        <span className="text-sm">Pending</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Complaint Details */}
            <div className="bg-gray-50 rounded-lg p-6 mb-8">
              <div className="grid grid-cols-2 gap-8">
                <div>
                  <p className="text-sm font-semibold text-gray-500 mb-2">ISSUE TYPE</p>
                  <p className="text-lg font-bold text-gray-900">{selectedComplaint.type}</p>
                </div>
                <div>
                  <p className="text-sm font-semibold text-gray-500 mb-2">SEVERITY</p>
                  <p className="text-lg font-bold text-gray-900">{selectedComplaint.severity}</p>
                </div>
                <div>
                  <p className="text-sm font-semibold text-gray-500 mb-2">LOCATION</p>
                  <p className="text-lg font-bold text-gray-900">{selectedComplaint.location}</p>
                </div>
                <div>
                  <p className="text-sm font-semibold text-gray-500 mb-2">DEPARTMENT</p>
                  <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600">
                    <option>Select Department</option>
                    <option>Roads & Infrastructure</option>
                    <option>Sanitation</option>
                    <option>Electricity</option>
                    <option>Water Supply</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            {activeTab === 'pending' && (
              <div className="flex gap-4">
                <button className="flex-1 px-6 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 transition font-medium flex items-center justify-center gap-2">
                  <XCircle className="w-5 h-5" />
                  Reject
                </button>
                <button className="flex-1 px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition font-medium flex items-center justify-center gap-2">
                  <CheckCircle className="w-5 h-5" />
                  Approve
                </button>
              </div>
            )}

            {activeTab === 'completed' && (
              <div className="bg-green-50 border border-green-200 rounded-lg p-4 flex items-center gap-3">
                <CheckCircle className="w-6 h-6 text-green-600 flex-shrink-0" />
                <div>
                  <p className="font-semibold text-green-900">Complaint Completed</p>
                  <p className="text-sm text-green-700">This complaint has been verified and marked as complete.</p>
                </div>
              </div>
            )}
          </div>
        ) : (
          // List View
          <div className="grid gap-4">
            {currentComplaints.map((complaint) => (
              <button
                key={complaint.id}
                onClick={() => setSelectedComplaint(complaint)}
                className="bg-white rounded-lg border border-gray-200 p-6 hover:shadow-lg transition text-left"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="text-lg font-bold text-gray-900 mb-2">{complaint.type}</h3>
                    <p className="text-gray-600 mb-3">{complaint.location}</p>
                    <div className="flex gap-4">
                      <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                        complaint.severity === 'High'
                          ? 'bg-red-100 text-red-800'
                          : complaint.severity === 'Medium'
                          ? 'bg-yellow-100 text-yellow-800'
                          : 'bg-blue-100 text-blue-800'
                      }`}>
                        {complaint.severity}
                      </span>
                      <span className="text-sm text-gray-500">{complaint.submittedDate}</span>
                    </div>
                  </div>
                  <Clock className="w-5 h-5 text-gray-400 flex-shrink-0" />
                </div>
              </button>
            ))}
            {currentComplaints.length === 0 && (
              <div className="text-center py-12 bg-white rounded-lg border border-gray-200">
                <p className="text-gray-600">No complaints in this category</p>
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
