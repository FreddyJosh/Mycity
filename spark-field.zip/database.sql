-- MyCity Database Schema
-- Run this script to create the necessary tables for the civic issue reporting system

CREATE DATABASE IF NOT EXISTS mycity_db;
USE mycity_db;

-- USERS Table
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role ENUM('citizen', 'admin', 'department') NOT NULL DEFAULT 'citizen',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_email (email),
  INDEX idx_role (role)
);

-- DEPARTMENTS Table
CREATE TABLE IF NOT EXISTS departments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  dept_name VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  description TEXT,
  contact_phone VARCHAR(20),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_email (email)
);

-- COMPLAINTS Table
CREATE TABLE IF NOT EXISTS complaints (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  before_image LONGBLOB NOT NULL,
  after_image LONGBLOB,
  issue_type_ai VARCHAR(100) NOT NULL,
  issue_type_admin VARCHAR(100),
  severity_ai VARCHAR(50) NOT NULL,
  severity_admin VARCHAR(50),
  dept_id INT,
  gps_lat DECIMAL(10, 8) NOT NULL,
  gps_lng DECIMAL(11, 8) NOT NULL,
  status ENUM(
    'pending_admin',
    'approved',
    'assigned',
    'in_progress',
    'completed',
    'rejected'
  ) NOT NULL DEFAULT 'pending_admin',
  ai_confidence DECIMAL(3, 2),
  similarity_score DECIMAL(3, 2),
  rejection_reason TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  completed_at TIMESTAMP NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (dept_id) REFERENCES departments(id) ON DELETE SET NULL,
  INDEX idx_user_id (user_id),
  INDEX idx_dept_id (dept_id),
  INDEX idx_status (status),
  INDEX idx_created_at (created_at),
  FULLTEXT INDEX ft_issue_type (issue_type_ai)
);

-- ADMIN_ACTIONS Table (for audit trail)
CREATE TABLE IF NOT EXISTS admin_actions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  admin_id INT NOT NULL,
  complaint_id INT NOT NULL,
  action VARCHAR(100) NOT NULL,
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (admin_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (complaint_id) REFERENCES complaints(id) ON DELETE CASCADE,
  INDEX idx_admin_id (admin_id),
  INDEX idx_complaint_id (complaint_id),
  INDEX idx_created_at (created_at)
);

-- DEPARTMENT_ACTIONS Table (for tracking department progress)
CREATE TABLE IF NOT EXISTS department_actions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  dept_id INT NOT NULL,
  complaint_id INT NOT NULL,
  action VARCHAR(100) NOT NULL,
  progress_status ENUM('pending', 'in_progress', 'completed') NOT NULL,
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (dept_id) REFERENCES departments(id) ON DELETE CASCADE,
  FOREIGN KEY (complaint_id) REFERENCES complaints(id) ON DELETE CASCADE,
  INDEX idx_dept_id (dept_id),
  INDEX idx_complaint_id (complaint_id),
  INDEX idx_created_at (created_at)
);

-- Insert demo data
INSERT INTO users (name, email, password, role) VALUES
('Rajesh Kumar', 'admin@mycity.gov', 'admin123', 'admin'),
('Roads Department', 'roads@mycity.gov', 'dept123', 'department'),
('Demo Citizen', 'citizen@example.com', 'citizen123', 'citizen');

INSERT INTO departments (dept_name, email, password, description, contact_phone) VALUES
('Roads & Infrastructure', 'roads@mycity.gov', 'dept123', 'Handles potholes, damaged roads, and infrastructure issues', '011-XXXX-XXXX'),
('Sanitation Department', 'sanitation@mycity.gov', 'sanit123', 'Manages garbage accumulation and street cleaning', '011-YYYY-YYYY'),
('Electricity Department', 'electricity@mycity.gov', 'elec123', 'Handles streetlight failures and electrical issues', '011-ZZZZ-ZZZZ'),
('Water Supply Department', 'water@mycity.gov', 'water123', 'Manages water supply and pipeline issues', '011-AAAA-AAAA'),
('Drainage Department', 'drainage@mycity.gov', 'drain123', 'Handles waterlogging and drainage issues', '011-BBBB-BBBB'),
('Traffic Department', 'traffic@mycity.gov', 'traffic123', 'Manages traffic signs and road markings', '011-CCCC-CCCC');

-- Create a view for dashboard statistics
CREATE OR REPLACE VIEW complaint_stats AS
SELECT
  COUNT(*) as total_complaints,
  SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
  SUM(CASE WHEN status = 'pending_admin' THEN 1 ELSE 0 END) as pending,
  SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved,
  SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected,
  AVG(CAST(ai_confidence AS DECIMAL(3, 2))) as avg_ai_confidence
FROM complaints;
